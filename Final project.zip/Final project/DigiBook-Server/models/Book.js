const mongoose = require("mongoose");

const bookSchema = new mongoose.Schema({
  name: { type: String, required: true },
  id: { type: Number, required: true, uniqe: true},
  category: { type: String, required: true },
  location: { type: String },
  borrower: { 
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    startDate: Date,
    endDate: Date
  },
  waitingList: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  image: { data: Buffer, contentType: String }
});

module.exports = mongoose.models.Book || mongoose.model("Book", bookSchema);
