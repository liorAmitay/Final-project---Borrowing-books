const mongoose = require("mongoose");

// User schema
const userSchema = new mongoose.Schema({
  fullName: { type: String, required: true },

  // ID (number)
  id: { 
    type: Number,
    required: true,
    min: 1111111,             // prevents 0 or negative
    max: 999999999,
    unique: true        // ensures no duplicate ID
  },

  email: { type: String, required: true, unique: true },
  cell: String,
  address: String,
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ["admin", "user"], default: "user" },
});

module.exports = mongoose.model("User", userSchema);
