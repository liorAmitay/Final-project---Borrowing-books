

   async function IsUserExist(model, userName, password) {
    try {
      // Query the database for a document with matching username and password
      const user = await model.findOne({userName, password });
  
      // Return true if a matching document is found, otherwise false
      return (!!user); // !! converts the object to a boolean (true if found, false if null)
    } catch (error) {

      console.error('Error checking user and password:', error);
      return false; // Return false in case of an error
    }
  }
  


  

