require('dotenv').config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const app = express();
app.use(cors());
app.use(express.json());

const { ensureAdminUser } = require("./routes/users");

const booksRouter = require("./routes/books");
const usersRouter = require("./routes/users");
const booksToUsersRouter = require("./routes/books_to_users");

const PORT = process.env.PORT || 3001;

// Connect to MongoDB
mongoose
  .connect(process.env.MONGO_URI, {
    serverSelectionTimeoutMS: 5000,
  })
  .then(async () => {
    console.log("✅ Connected to MongoDB");

    // Ensure admin exists
    await ensureAdminUser();

    // Start server here...
  });

// Routes
app.use("/books", booksRouter);
app.use("/users", usersRouter);
app.use("/booksToUsers", booksToUsersRouter);

app.listen(PORT, () => console.log(`✅ Server running on port ${PORT}`));
