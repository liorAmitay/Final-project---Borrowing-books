const express = require("express");
const router = express.Router();
const Book = require("../models/Book");
const multer = require("multer");

const { auth, adminOnly } = require("../routes/middlewares");
// Apply auth to ALL routes after this line(except register \ login functions)
router.use(auth);

// Memory storage for in-memory Buffer
const storage = multer.memoryStorage();
const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 } // max 5MB
});


// Create book with image
router.post("/",adminOnly,  upload.single("image"), async (req, res) => {
  try {
    const bookData = { ...req.body };

    //create book ID - shorten one
    const lastBook = await Book.findOne().sort({ id: -1 });

    // If no books exist → start at 1
    const newId = lastBook ? lastBook.id + 1 : 1;

    // Add the generated ID to the new book
    bookData.id = newId;

    if (req.file) {
      bookData.image = {
        data: req.file.buffer,
        contentType: req.file.mimetype
      };
    }

    const book = new Book(bookData);
    await book.save();
    res.status(201).json(book);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Update book with optional image
router.put("/:id",adminOnly,  upload.single("image"), async (req, res) => {
  try {
    const updateData = {
      category: req.body.category,
      amount: req.body.amount,
      location: req.body.location
    };

    if (req.file) {
      updateData.image = {
        data: req.file.buffer,
        contentType: req.file.mimetype
      };
    }

    const updatedBook = await Book.findByIdAndUpdate(req.params.id, updateData, { new: true });

    if (!updatedBook) return res.status(404).json({ error: "Book not found" });
    res.json(updatedBook);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});


// Delete book by ID
router.delete("/:id",adminOnly,  async (req, res) => {
  try {
    const book = await Book.findByIdAndDelete(req.params.id);

    if (!book) return res.status(404).json({ error: "Book not found" });

    res.json({ message: "Book deleted successfully", book });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});


// Get all books or filter by name/category
router.get("/", async (req, res) => {
  try {
    const { name, category } = req.query;
    const filter = {};

    if (name) {
      filter.name = { $regex: name, $options: "i" }; // case-insensitive search
    }
    if (category && category !== "All Categories") {
      filter.category = { $regex: category, $options: "i" };
    }
    const books = await Book.find(filter).populate("borrower.userId", "fullName id");
    const booksWithBase64 = books.map(b => ({
      ...b.toObject(),
      image: b.image?.data ? `data:${b.image.contentType};base64,${b.image.data.toString('base64')}` : null
    }));

    res.json(booksWithBase64);

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error fetching books" });
  }
});

// GET unique categories
router.get("/categories", async (req, res) => {
  try {
    const categories = await Book.distinct("category"); // unique category names
    res.json(categories);
  } catch (error) {
    console.error("Error fetching categories:", error);
    res.status(500).json({ message: "Error fetching categories" });
  }
});

module.exports = router;
