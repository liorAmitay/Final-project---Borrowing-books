const express = require("express");
const router = express.Router();
const User = require("../models/User");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");

const { auth, adminOnly } = require("../routes/middlewares");

const JWT_SECRET = process.env.JWT_SECRET;
const TOKEN_EXPIRE = process.env.TOKEN_EXPIRE;

// Register route (no JWT)

router.post("/register", async (req, res) => {
  try {

    const { fullName, id, email, cell, address, username, password } = req.body;

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = new User({ fullName,id, email, cell, address, username, password: hashedPassword });
    await user.save();

    res.json({ message: "User registered successfully" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Login route (returns JWT)
router.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;

    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ error: "Invalid username or password" });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ error: "Invalid username or password" });

    const token = jwt.sign({ id: user._id, username: user.username, role: user.role },
                             JWT_SECRET,
                             { expiresIn: TOKEN_EXPIRE });
    res.json({ token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

  // Create admin user automatically when the server is up
  async function ensureAdminUser() {
  try {
    const existingAdmin = await User.findOne({ username: "Admin" });
    if (existingAdmin) {
      console.log("✔ Admin user already exists");
      return;
    }

    const hashedPassword = await bcrypt.hash("Admin123", 10);

    const admin = new User({
      fullName: "System Administrator",
      id: 1235678, // or any number that doesn’t conflict with real users
      email: "admin@example.com",
      username: "Admin",
      password: hashedPassword,
      role: "admin",
    });

    await admin.save();
    console.log("✔ Admin user created automatically");
  } catch (error) {
    console.error("❌ Failed to create admin user:", error.message);
  }
}

// Apply auth to ALL routes after this line(except register \ login functions)
console.log("type:  " + typeof(auth))
router.use(auth);

// Protected home route
router.get("/home",adminOnly,  async (req, res) => {

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    res.json({ message: `Welcome ${decoded.username}!` });
  } catch (err) {
    res.status(403).json({ error: "Invalid or expired token" });
  }
});


// Delete a user
router.delete("/:id",adminOnly,  async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: "User deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// (Optional) Update a user
router.put("/:id", async (req, res) => {
  try {
    const updatedUser = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedUser);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});


// GET /api/users?fullName=lior&email=gmail
router.get("/", adminOnly, async (req, res) => {
  try {
    const { fullName, id , email, cell, address } = req.query;
    const query = {};

    if (fullName) query.fullName = { $regex: fullName, $options: "i" };
    if (id) query.id = Number(id); 
    if (email) query.email = { $regex: email, $options: "i" };
    if (cell) query.cell = { $regex: cell, $options: "i" };
    if (address) query.address = { $regex: address, $options: "i" };

    const users = await User.find(query);
    console.log(users)
    res.json(users);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
module.exports.ensureAdminUser = ensureAdminUser;

