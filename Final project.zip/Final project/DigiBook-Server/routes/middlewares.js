const jwt = require("jsonwebtoken");

//Middlewere for checking the token of each request to server:
function auth(req, res, next) {
  const headerToken = req.header("Authorization");

  if (!headerToken)
    return res.status(401).json({ msg: "No token. Access denied." });

  // Remove "Bearer "
  const token = headerToken.replace("Bearer ", "");

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // { id, fullName, role, iat, exp }
    next();
  } catch (err) {
    return res.status(401).json({ msg: "Token expired or invalid" });
  }
}

//Middlewere for users permissions - part of the functions are not allwoed for role: "user"
function adminOnly(req, res, next) {
  if (!req.user)
    return res.status(401).json({ msg: "Not authenticated" });

  if (req.user.role !== "admin")
    return res.status(403).json({ msg: "Access denied: Admins only" });

  next();
}

module.exports = { auth, adminOnly };
