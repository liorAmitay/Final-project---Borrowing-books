const express = require("express");
const router = express.Router();
const Book = require("../models/Book");
const User = require("../models/User");

const { auth, adminOnly } = require("../routes/middlewares");
// Apply auth to ALL routes under this line
router.use(auth);

// GET all books
router.get("/", async (req, res) => {
  try {
    const books = await Book.find()
      .populate("borrower.userId", "fullName id")
      .populate("waitingList", "fullName id");

    const result = books.map(book => {
      const waitingNames = book.waitingList
        .map(u => `${u.fullName} (${u.id})`)
        .join(", ") || "None";

      let remainingTime = "-";
      if (book.borrower && book.borrower.endDate) {
        const now = new Date();
        let diffMs = book.borrower.endDate - now;
        if (diffMs < 0) diffMs = 0;

        const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);

        remainingTime = `${days}d ${hours}h ${minutes}m ${seconds}s`;
      }

      return {
        _id: book._id,
        id:book.id,
        name: book.name,
        category: book.category,
        borrower: book.borrower,
        waitingNames,
        remainingTime
      };
    });

    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});


// 🔍 Search user by ID or full name
router.get("/search", async (req, res) => {
  try {
    const { id, fullName } = req.query;

    if (!id && !fullName) {
      return res.status(400).json({ message: "Missing search parameters" });
    }

    const orConditions = [];

    if (id && !isNaN(id)) {
      orConditions.push({ id: Number(id) });
    }

    if (fullName && fullName.trim() !== "") {
      const search = fullName.trim();
      orConditions.push({ fullName: { $regex: new RegExp("^" + search, "i") } });
    }

    if (orConditions.length === 0) {
      return res.status(400).json({ message: "Invalid search parameters" });
    }

    const users = await User.find({ $or: orConditions }).select("fullName id email cell address");

    if (!users || users.length === 0) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json(users);
  } catch (err) {
    console.error("Search failed:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// Borrow book
router.put("/:bookId/borrow", adminOnly,  async (req, res) => {
  try {
    const { userId, startDate, endDate } = req.body;
    const book = await Book.findById(req.params.bookId);
    if (!book) return res.status(404).json({ message: "Book not found" });

    if (book.borrower && book.borrower.userId) {
      return res.status(400).json({ message: "Book already borrowed" });
    }

    // Remove from waiting list
    book.waitingList = book.waitingList.filter(id => id.toString() !== userId.toString());

    book.borrower = {
      userId,
      startDate: new Date(startDate),
      endDate: new Date(endDate)
    };

    await book.save();
    res.json({ message: "Book borrowed successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

// Add user to waiting list
router.put("/:bookId/waiting", async (req, res) => {
  try {
    const { userId } = req.body;
    const book = await Book.findById(req.params.bookId);
    if (!book) return res.status(404).json({ message: "Book not found" });

    // Avoid duplicates
    if (book.waitingList.includes(userId)) {
      return res.status(400).json({ message: "User already in waiting list" });
    }

    book.waitingList.push(userId);
    await book.save();
    res.json({ message: "User added to waiting list" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});


// Remove user from waiting list
router.put("/:bookId/cancel-wait", async (req, res) => {
  try {
    const { userId } = req.body;
    const book = await Book.findById(req.params.bookId);
    if (!book) return res.status(404).json({ message: "Book not found" });

    // Remove user from waiting list
    book.waitingList = book.waitingList.filter(id => id.toString() !== userId);
    await book.save();

    res.json({ message: "User removed from waiting list" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});


// Return book
router.put("/:bookId/return",adminOnly,  async (req, res) => {
  try {
    const { userId } = req.body;
    const book = await Book.findById(req.params.bookId);
    if (!book) return res.status(404).json({ message: "Book not found" });

    if (!book.borrower || book.borrower.userId.toString() !== userId.toString()) {
      return res.status(400).json({ message: "User did not borrow this book" });
    }

    // Calculate remaining time
    const now = new Date();
    const diffMs = book.borrower.endDate - now;
    const remainingDays = Math.max(0, Math.floor(diffMs / (1000 * 60 * 60 * 24)));

    book.borrower = null;
    await book.save();

    res.json({ message: `Book returned successfully. Remaining days: ${remainingDays}` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
