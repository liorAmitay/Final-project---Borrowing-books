Installation instructions:
1.Unzip the Final project folder
2.Open the final project folder from vs code
3.
Server -
Get to the digibook-server folder from the terminal in VS code by running "cd digibook-server"
(All the models are already inside, in case it didn't go through the compression run npm install)
Make sure mongo db is installed by the command "mongod --version", if it doesn't anything or an error is returned, and you need to install from their website.
Running the server by "nodemon index.js"
4.
Client -
Get to the index.html folder in the digibook-client folder right click on the page and select "open by Live server" or from anywhere else.
Get to the mark on the Debug side and click Play
Get to the Login screen
To view the App with all the options log in
User: Admin
Password: Admin123
To see what a regular user sees you need to register and then log in so first enter to Register tab.
(In Insert book operation you can an image from DigBook-Client\ images folder that already exists in this root)