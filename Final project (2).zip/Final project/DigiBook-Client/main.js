const serverURL = "http://localhost:3001/users";

// Register a new user
async function register() {
  // Gather user input
  const fullName = document.getElementById("regFullName").value.trim();
  const id = document.getElementById("regID").value.trim();
  const email = document.getElementById("regEmail").value.trim();
  const cell = document.getElementById("regCell").value.trim();
  const address = document.getElementById("regAddress").value.trim();
  const username = document.getElementById("regName").value.trim();
  const password = document.getElementById("regPass").value.trim();

  hideMessage(); // Clear previous alerts

  // Validate required fields
  if (!fullName || !id || !email || !username || !password) {
    return showMessage("Please fill in all required fields.", "error");
  }

  try {
    // Send registration request to server
    const res = await fetch(`${serverURL}/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fullName, id, email, cell, address, username, password }),
    });

    const data = await res.json();
    
    // Handle server response
    if (res.ok) {
      showMessage(`Register Success: ${data.message}`, "success");
    } else {
      showMessage(`Register Failed: ${data.error}`, "error");
    }
  } catch (err) {
    showMessage(`Network Error: ${err.message}`, "error");
  }
}

// Authenticate user and handle login
async function login(redirect = false) {
  const username = document.getElementById("loginName").value.trim();
  const password = document.getElementById("loginPass").value.trim();

  hideMessage(); 

  if (!username || !password) {
    return showMessage("Please enter username and password.", "error");
  }

  try {
    // Send login request
    const res = await fetch(`${serverURL}/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });

    const data = await res.json();
    console.log("data: " + data.token);

    // Process successful login
    if (res.ok && data.token) {
      localStorage.setItem("token", data.token); // Save JWT token
      showMessage(`Login Success!`, "success");

      if (redirect) {
        window.location.href = "pages/home_page.html";
      }
    } else {
      showMessage(`Login Failed: ${data.error}`, "error");
    }
  } catch (err) {
    showMessage(`Network Error: ${err.message}`, "error");
  }
}

// Display formatted UI alerts (Success/Error)
function showMessage(message, type = 'error') {
  const alertBox = document.getElementById('alertBox');
  const alertText = document.getElementById('alertText');
  const alertIcon = document.getElementById('alertIcon');

  // Reset alert styles
  alertBox.className = 'alert d-flex align-items-center mt-4 mb-0 shadow-sm';
  alertIcon.className = 'bi me-2 fs-5';

  // Apply styles based on message type
  if (type === 'error') {
    alertBox.classList.add('alert-danger', 'border-danger');
    alertIcon.classList.add('bi-exclamation-triangle-fill'); 
  } else if (type === 'success') {
    alertBox.classList.add('alert-success', 'border-success');
    alertIcon.classList.add('bi-check-circle-fill'); 
  }

  alertText.innerText = message;
  alertBox.classList.remove('d-none'); // Show the alert
}

// Hide the UI alert box
function hideMessage() {
  const alertBox = document.getElementById('alertBox');
  if (alertBox) {
    alertBox.classList.add('d-none');
  }
}